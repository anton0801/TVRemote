// Contact form: sends through contact.php when the host runs PHP; otherwise (static hosting,
// network error, mail() failure) opens the visitor's mail app with the same message.
(function () {
  var form = document.getElementById("contact-form");
  if (!form || !window.fetch || !window.FormData) return;
  var status = document.getElementById("form-status");
  var button = form.querySelector('button[type="submit"]');
  var label = button.querySelector("span");
  var idle = label.textContent;
  var text = form.dataset;

  function show(kind, message, title) {
    status.className = "form-status " + kind;
    status.textContent = "";
    if (title) {
      var strong = document.createElement("strong");
      strong.textContent = title + " ";
      status.appendChild(strong);
    }
    status.appendChild(document.createTextNode(message));
    status.hidden = false;
  }

  function busy(on) {
    button.disabled = on;
    label.textContent = on ? text.sending : idle;
  }

  function openMailApp() {
    if (!text.to) return show("error", text.invalid);
    var topic = form.topic.options[form.topic.selectedIndex].text;
    var body = form.message.value.trim() + "\n\n" +
      (form.tv.value.trim() ? "TV: " + form.tv.value.trim() + "\n" : "") +
      "Reply to: " + form.email.value.trim();
    window.location.href = "mailto:" + text.to + "?subject=" + encodeURIComponent("TV Remote support: " + topic) +
      "&body=" + encodeURIComponent(body);
    show("info", text.mailapp);
  }

  form.addEventListener("submit", function (event) {
    event.preventDefault();
    if (button.disabled) return;
    var email = form.email.value.trim();
    var message = form.message.value.trim();
    form.email.setAttribute("aria-invalid", form.email.checkValidity() && email ? "false" : "true");
    form.message.setAttribute("aria-invalid", message.length >= 10 ? "false" : "true");
    if (!email || !form.email.checkValidity() || message.length < 10) {
      show("error", text.invalid);
      (email && form.email.checkValidity() ? form.message : form.email).focus();
      return;
    }
    busy(true);
    fetch(form.getAttribute("action"), { method: "POST", body: new FormData(form), headers: { Accept: "application/json" } })
      .then(function (response) {
        var type = response.headers.get("content-type") || "";
        return type.indexOf("application/json") !== -1 ? response.json() : null;
      })
      .then(function (result) {
        busy(false);
        if (result && result.ok) {
          form.reset();
          show("success", text.sent, text.sentTitle);
        } else if (result && result.result === "invalid") {
          show("error", text.invalid);
        } else {
          openMailApp();
        }
      })
      .catch(function () {
        busy(false);
        openMailApp();
      });
  });
})();
